# 🚀 完整部署指南

## 目录
1. [环境准备](#环境准备)
2. [Hermes Agent安装](#hermes-agent安装)
3. [API配置](#api配置)
4. [脚本部署](#脚本部署)
5. [定时任务设置](#定时任务设置)
6. [故障排查](#故障排查)

---

## 环境准备

### 方案A: 本地Mac部署
**优点**: 免费，适合测试
**缺点**: 需要电脑24小时开机

**要求**:
- macOS 12+
- Python 3.9+
- 能访问Google的代理

### 方案B: VPS部署（推荐）
**优点**: 24小时运行，稳定可靠
**缺点**: 需要$5/月成本

**推荐VPS**:
- Vultr: $5/月，日本节点
- DigitalOcean: $6/月，新加坡节点
- 搬瓦工: ¥30/月，CN2线路

---

## Hermes Agent安装

### 1. 安装Python环境
```bash
# Mac自带Python，检查版本
python3 --version

# 如果版本低于3.9，使用Homebrew升级
brew install python@3.11
```

### 2. 安装Hermes Agent
```bash
pip3 install hermes-agent
```

### 3. 验证安装
```bash
hermes --version
```

---

## API配置

### 1. 获取DeepSeek API Key

1. 访问 [platform.deepseek.com](https://platform.deepseek.com)
2. 注册账号
3. 充值$1（可用一个月）
4. 创建API Key

### 2. 创建Telegram Bot

1. 在Telegram搜索 `@BotFather`
2. 发送 `/newbot`
3. 按提示创建Bot
4. 保存Bot Token

### 3. 配置Hermes

编辑 `~/.hermes/config.yaml`:

```yaml
models:
  default:
    provider: deepseek
    model: deepseek-chat
    api_key: "sk-your-deepseek-key"

telegram:
  bot_token: "your-telegram-bot-token"
  home_channel: "your-telegram-user-id"

proxy:
  http_proxy: "http://127.0.0.1:7890"
  https_proxy: "http://127.0.0.1:7890"
```

**获取Telegram User ID**:
1. 在Telegram搜索 `@userinfobot`
2. 发送任意消息
3. 复制返回的ID

---

## 脚本部署

### 1. 复制脚本文件
```bash
# 解压产品包
unzip ai-money-system-v2.0.zip

# 复制脚本到Hermes目录
cp -r ai-money-system-v2.0/scripts/*.py ~/.hermes/scripts/
```

### 2. 配置脚本参数

编辑 `~/.hermes/scripts/config.json`:

```json
{
  "grvt_referral_code": "your-grvt-code",
  "binance_referral_code": "your-binance-code",
  "telegram_chat_id": "your-telegram-id"
}
```

---

## 定时任务设置

### 1. 内容套利任务

**Twitter→小红书**（每3小时）:
```
cronjob action=create schedule="0 */3 * * *" prompt="运行content_arbitrage.py脚本"
```

**YouTube→B站**（每天10:00/18:00）:
```
cronjob action=create schedule="0 10,18 * * *" prompt="运行youtube_bilibili.py脚本"
```

**ProductHunt→即刻**（每天12:00/20:00）:
```
cronjob action=create schedule="0 12,20 * * *" prompt="运行producthunt_jike.py脚本"
```

**GitHub→掘金**（每天11:00/19:00）:
```
cronjob action=create schedule="0 11,19 * * *" prompt="运行github_juejin.py脚本"
```

### 2. 加密监控任务

**Meme币监控**（每小时）:
```
cronjob action=create schedule="0 * * * *" prompt="运行meme_monitor.py脚本"
```

**空投监控**（每6小时）:
```
cronjob action=create schedule="0 */6 * * *" prompt="运行airdrop_monitor.py脚本"
```

**加密市场日报**（每天10:00）:
```
cronjob action=create schedule="0 10 * * *" prompt="运行crypto_market_monitor.py脚本"
```

### 3. 推广返佣任务

**GRVT推广**（每天12:00/20:00）:
```
cronjob action=create schedule="0 12,20 * * *" prompt="运行grvt_promo.py脚本"
```

**CryptoDAO推广**（每天11:00/19:00）:
```
cronjob action=create schedule="0 11,19 * * *" prompt="运行cryptodao_promo.py脚本"
```

### 4. 查看所有任务
```
cronjob action=list
```

---

## 故障排查

### 问题1: Telegram推送失败

**症状**: 脚本运行正常，但收不到Telegram消息

**解决方案**:
1. 检查Bot Token是否正确
2. 确认已经给Bot发送过消息（激活Bot）
3. 检查User ID是否正确
4. 测试代理是否能访问api.telegram.org

### 问题2: API调用失败

**症状**: 脚本报错"API key invalid"

**解决方案**:
1. 检查DeepSeek API Key是否正确
2. 确认账户余额充足
3. 检查API Key权限设置

### 问题3: 定时任务不执行

**症状**: 创建了定时任务，但从不运行

**解决方案**:
1. 检查cron表达式是否正确
2. 查看Hermes日志: `hermes logs`
3. 手动运行脚本测试: `python3 ~/.hermes/scripts/xxx.py`

### 问题4: 代理连接失败

**症状**: 脚本报错"Connection timeout"

**解决方案**:
1. 检查代理软件是否运行
2. 确认代理端口号正确
3. 测试代理: `curl -x http://127.0.0.1:7890 https://google.com`

---

## 进阶优化

### 1. 提高内容质量
- 使用GPT-4替代DeepSeek（成本更高，质量更好）
- 添加人工审核环节
- 定制化内容模板

### 2. 扩展赚钱渠道
- 添加更多平台（抖音、快手、视频号）
- 接入更多返佣平台
- 开发自己的虚拟产品

### 3. 自动化发布
- 使用Playwright自动发布到小红书
- 使用Selenium自动发布到B站
- 使用API直接发布到Twitter

---

## 技术支持

遇到问题？联系我们：
- Telegram: @hermes_vk_bot
- 技术支持群: 购买后提供

---

**祝你早日实现自动化赚钱！💰**
