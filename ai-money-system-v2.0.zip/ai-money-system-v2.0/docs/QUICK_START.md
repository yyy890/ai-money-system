# 🚀 5分钟快速启动

## 前置条件
- Mac电脑或VPS（$5/月即可）
- 能访问Google的代理
- Telegram账号（接收推送）

---

## 部署步骤

### Step 1: 安装Hermes Agent
```bash
pip3 install hermes-agent
```

### Step 2: 配置API密钥
编辑 `~/.hermes/config.yaml`，填入：
- DeepSeek API Key（$1可用一个月）
- Telegram Bot Token（免费）
- 代理地址

### Step 3: 复制脚本
```bash
cp scripts/*.py ~/.hermes/scripts/
```

### Step 4: 启动定时任务
在Hermes中运行：
```
cronjob action=create schedule="every 3h" prompt="运行内容套利脚本"
```

### Step 5: 坐等收钱
系统自动运行，所有内容推送到Telegram，你只需复制发布。

---

## 详细教程
参见 `DEPLOYMENT_GUIDE.md`
