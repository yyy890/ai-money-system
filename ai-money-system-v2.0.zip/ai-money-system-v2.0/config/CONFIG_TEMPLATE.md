# 配置文件模板

## 1. Hermes Agent 配置

文件路径: `~/.hermes/config.yaml`

```yaml
models:
  default:
    provider: deepseek
    model: deepseek-chat
    api_key: "sk-your-deepseek-api-key-here"

telegram:
  bot_token: "your-telegram-bot-token-here"
  home_channel: "your-telegram-user-id-here"

proxy:
  http_proxy: "http://127.0.0.1:7890"
  https_proxy: "http://127.0.0.1:7890"
```

## 2. 脚本配置

文件路径: `~/.hermes/scripts/config.json`

```json
{
  "grvt_referral_code": "your-grvt-referral-code",
  "binance_referral_code": "your-binance-referral-code",
  "cryptodao_referral_code": "your-cryptodao-referral-code",
  "telegram_chat_id": "your-telegram-user-id",
  "output_dir": "~/hermes_output"
}
```

## 3. 获取配置信息

### DeepSeek API Key
1. 访问 https://platform.deepseek.com
2. 注册账号
3. 充值 $1（可用一个月）
4. 创建 API Key

### Telegram Bot Token
1. 在 Telegram 搜索 `@BotFather`
2. 发送 `/newbot`
3. 按提示创建 Bot
4. 保存 Bot Token

### Telegram User ID
1. 在 Telegram 搜索 `@userinfobot`
2. 发送任意消息
3. 复制返回的 ID

### GRVT Referral Code
1. 访问 https://grvt.io
2. 注册账号
3. 进入推广中心
4. 生成返佣链接
5. 提取链接中的 referral code

### Binance Referral Code
1. 访问 https://www.binance.com
2. 注册账号并完成实名认证
3. 进入推广中心
4. 生成返佣链接
5. 提取链接中的 referral code

### CryptoDAO Referral Code
1. 访问 https://cryptodao.ai
2. 连接钱包
3. 进入推广页面
4. 生成返佣链接
5. 提取链接中的 referral code

## 4. 代理配置

### Mac 用户（Shadowrocket/ClashX）
```yaml
proxy:
  http_proxy: "http://127.0.0.1:7890"
  https_proxy: "http://127.0.0.1:7890"
```

### VPS 用户（自建代理）
```yaml
proxy:
  http_proxy: "http://your-proxy-ip:port"
  https_proxy: "http://your-proxy-ip:port"
```

## 5. 配置检查清单

安装完成后，请检查以下配置：

- [ ] DeepSeek API Key 已填写
- [ ] Telegram Bot Token 已填写
- [ ] Telegram User ID 已填写
- [ ] 代理地址已配置
- [ ] GRVT Referral Code 已填写（可选）
- [ ] Binance Referral Code 已填写（可选）
- [ ] CryptoDAO Referral Code 已填写（可选）

## 6. 测试配置

```bash
# 测试 Hermes Agent
hermes --version

# 测试 Telegram Bot
curl https://api.telegram.org/bot<your-token>/getMe

# 测试代理
curl -x http://127.0.0.1:7890 https://google.com

# 测试 DeepSeek API
curl https://api.deepseek.com/v1/models \
  -H "Authorization: Bearer sk-your-key"
```

## 7. 常见问题

**Q: 代理端口号是多少？**
A: 
- Shadowrocket: 默认 7890
- ClashX: 默认 7890
- V2rayU: 默认 1087

**Q: Telegram Bot 收不到消息？**
A: 
1. 检查 Bot Token 是否正确
2. 确认已经给 Bot 发送过消息（激活 Bot）
3. 检查 User ID 是否正确
4. 测试代理是否能访问 api.telegram.org

**Q: DeepSeek API 调用失败？**
A:
1. 检查 API Key 是否正确
2. 确认账户余额充足
3. 检查 API Key 权限设置

---

**配置完成后，请运行快速启动指南中的测试命令验证配置是否正确。**
