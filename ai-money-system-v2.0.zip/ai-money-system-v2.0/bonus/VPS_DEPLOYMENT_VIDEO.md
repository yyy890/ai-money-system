# 🎬 VPS部署视频教程

## 视频教程说明

由于视频文件较大，我们提供了详细的图文教程和关键步骤截图。

如果你是Pro版用户，可以联系客服获取完整视频教程。

---

## 教程1: VPS购买和配置

### 1. 购买VPS

**推荐平台**: Vultr

**步骤**:
1. 访问 https://www.vultr.com
2. 注册账号
3. 选择服务器配置：
   - 地区：日本东京
   - 系统：Ubuntu 22.04
   - 配置：$5/月（1核1G）
4. 完成支付

**关键截图**:
```
[VPS购买页面截图]
- 地区选择
- 系统选择
- 配置选择
- 支付页面
```

### 2. 连接VPS

**Mac/Linux**:
```bash
ssh root@your-vps-ip
```

**Windows**:
1. 下载PuTTY
2. 输入VPS IP
3. 输入用户名和密码

**关键截图**:
```
[SSH连接截图]
- 终端连接成功
- 输入密码
- 登录成功
```

### 3. 配置代理

**安装Shadowsocks**:
```bash
# 安装Docker
curl -fsSL https://get.docker.com | sh

# 启动Shadowsocks
docker run -d --name ss \
  -p 8388:8388 \
  shadowsocks/shadowsocks-libev \
  ss-server -s 0.0.0.0 -p 8388 -k your-password -m aes-256-gcm
```

**关键截图**:
```
[代理配置截图]
- Docker安装成功
- Shadowsocks启动成功
- 连接测试成功
```

---

## 教程2: Hermes Agent安装

### 1. 安装Python环境

```bash
# 更新系统
apt update && apt upgrade -y

# 安装Python
apt install python3 python3-pip -y

# 验证安装
python3 --version
pip3 --version
```

**关键截图**:
```
[Python安装截图]
- apt update输出
- Python版本信息
- pip版本信息
```

### 2. 安装Hermes Agent

```bash
# 安装Hermes
pip3 install hermes-agent

# 验证安装
hermes --version
```

**关键截图**:
```
[Hermes安装截图]
- pip安装输出
- hermes版本信息
```

### 3. 配置Hermes

```bash
# 创建配置文件
mkdir -p ~/.hermes
vim ~/.hermes/config.yaml
```

**配置内容**:
```yaml
models:
  default:
    provider: deepseek
    model: deepseek-chat
    api_key: "sk-your-deepseek-key"

telegram:
  bot_token: "your-telegram-bot-token"
  home_channel: "your-telegram-user-id"

proxy:
  http_proxy: "http://127.0.0.1:8388"
  https_proxy: "http://127.0.0.1:8388"
```

**关键截图**:
```
[配置文件截图]
- vim编辑界面
- 配置文件内容
- 保存成功
```

---

## 教程3: 脚本部署

### 1. 上传脚本

**方法1: SCP上传**:
```bash
# 在本地执行
scp -r scripts/*.py root@your-vps-ip:~/.hermes/scripts/
```

**方法2: Git克隆**:
```bash
# 在VPS执行
cd ~/.hermes/scripts/
git clone https://github.com/your-repo/ai-money-system.git
cp ai-money-system/scripts/*.py .
```

**关键截图**:
```
[脚本上传截图]
- SCP上传进度
- 文件列表
- 上传成功
```

### 2. 测试脚本

```bash
# 测试单个脚本
python3 ~/.hermes/scripts/content_arbitrage.py
```

**关键截图**:
```
[脚本测试截图]
- 脚本运行输出
- Telegram推送成功
```

### 3. 启动定时任务

```bash
# 启动Hermes Gateway
hermes gateway start

# 创建定时任务
hermes cronjob create \
  --schedule "0 */3 * * *" \
  --prompt "运行content_arbitrage.py脚本"
```

**关键截图**:
```
[定时任务截图]
- Gateway启动成功
- 定时任务创建成功
- 任务列表
```

---

## 教程4: 监控和维护

### 1. 查看日志

```bash
# 查看Gateway日志
hermes logs

# 查看定时任务日志
hermes cronjob logs
```

**关键截图**:
```
[日志查看截图]
- Gateway日志
- 定时任务日志
- 错误信息
```

### 2. 重启服务

```bash
# 重启Gateway
hermes gateway restart

# 重启定时任务
hermes cronjob restart
```

**关键截图**:
```
[服务重启截图]
- 重启命令输出
- 服务状态
```

### 3. 更新脚本

```bash
# 更新脚本
cd ~/.hermes/scripts/
git pull

# 重启定时任务
hermes cronjob restart
```

**关键截图**:
```
[脚本更新截图]
- git pull输出
- 更新成功
```

---

## 教程5: 故障排查

### 1. Telegram推送失败

**检查步骤**:
```bash
# 测试代理
curl -x http://127.0.0.1:8388 https://api.telegram.org

# 测试Bot Token
curl https://api.telegram.org/bot<your-token>/getMe

# 查看日志
hermes logs | grep telegram
```

**关键截图**:
```
[故障排查截图]
- 代理测试结果
- Bot Token测试结果
- 日志错误信息
```

### 2. API调用失败

**检查步骤**:
```bash
# 测试API Key
curl https://api.deepseek.com/v1/models \
  -H "Authorization: Bearer sk-your-key"

# 查看余额
curl https://api.deepseek.com/v1/dashboard/billing/usage \
  -H "Authorization: Bearer sk-your-key"
```

**关键截图**:
```
[API测试截图]
- API测试结果
- 余额查询结果
```

### 3. 定时任务不执行

**检查步骤**:
```bash
# 查看任务列表
hermes cronjob list

# 查看任务详情
hermes cronjob show <job-id>

# 手动执行任务
hermes cronjob run <job-id>
```

**关键截图**:
```
[任务检查截图]
- 任务列表
- 任务详情
- 手动执行结果
```

---

## 完整视频教程

Pro版用户可以获取完整的视频教程，包括：

1. **VPS购买和配置**（15分钟）
   - VPS选择和购买
   - SSH连接和配置
   - 代理安装和测试

2. **Hermes Agent安装**（10分钟）
   - Python环境安装
   - Hermes安装和配置
   - API密钥配置

3. **脚本部署**（20分钟）
   - 脚本上传
   - 脚本测试
   - 定时任务创建

4. **监控和维护**（10分钟）
   - 日志查看
   - 服务重启
   - 脚本更新

5. **故障排查**（15分钟）
   - 常见问题诊断
   - 解决方案演示
   - 最佳实践

**总时长**: 70分钟

---

## 获取视频教程

**Pro版用户**:
1. 联系客服：@hermes_vk_bot
2. 提供订单号
3. 获取视频下载链接

**基础版用户**:
- 可以升级到Pro版获取视频教程
- 或者按照图文教程操作

---

**祝你部署顺利！💰**
